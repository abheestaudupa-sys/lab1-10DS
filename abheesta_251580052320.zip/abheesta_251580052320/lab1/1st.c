#include <stdio.h>
#include <stdlib.h>

struct PolyNode {
    int coeff;
    int exp;
    struct PolyNode* prev;
    struct PolyNode* next;
};

struct PolyNode* createNode(int coeff, int exp) {
    struct PolyNode* newNode = (struct PolyNode*)malloc(sizeof(struct PolyNode));
    newNode->coeff = coeff;
    newNode->exp = exp;
    newNode->prev = NULL;
    newNode->next = NULL;
    return newNode;
}

void insertSorted(struct PolyNode** head, struct PolyNode** tail, int coeff, int exp) {
    if (coeff == 0) return;

    struct PolyNode* newNode = createNode(coeff, exp);

    if (*head == NULL) {
        *head = *tail = newNode;
        return;
    }

    struct PolyNode* current = *head;

    while (current != NULL && current->exp > exp) {
        current = current->next;
    }

    if (current != NULL && current->exp == exp) {
        current->coeff += coeff;
        free(newNode);
        if (current->coeff == 0) {
            if (current->prev != NULL) current->prev->next = current->next;
            else *head = current->next;

            if (current->next != NULL) current->next->prev = current->prev;
            else *tail = current->prev;

            free(current);
        }
        return;
    }

    if (current == *head) {
        newNode->next = *head;
        (*head)->prev = newNode;
        *head = newNode;
    } else if (current == NULL) {
        (*tail)->next = newNode;
        newNode->prev = *tail;
        *tail = newNode;
    } else {
        newNode->next = current;
        newNode->prev = current->prev;
        current->prev->next = newNode;
        current->prev = newNode;
    }
}

void displayPolynomial(struct PolyNode* head) {
    if (head == NULL) {
        printf("0\n");
        return;
    }
    struct PolyNode* temp = head;
    int firstTerm = 1;
    while (temp != NULL) {
        if (!firstTerm) {
            if (temp->coeff > 0) printf(" + ");
            else printf(" - ");
        } else {
            if (temp->coeff < 0) printf("-");
            firstTerm = 0;
        }

        int absCoeff = temp->coeff < 0 ? -temp->coeff : temp->coeff;

        if (temp->exp == 0) {
            printf("%d", absCoeff);
        } else if (temp->exp == 1) {
            printf("%dx", absCoeff);
        } else {
            printf("%dx^%d", absCoeff, temp->exp);
        }
        temp = temp->next;
    }
    printf("\n");
}

struct PolyNode* addPolynomials(struct PolyNode* p1, struct PolyNode* p2) {
    struct PolyNode* resHead = NULL;
    struct PolyNode* resTail = NULL;

    struct PolyNode* t1 = p1;
    struct PolyNode* t2 = p2;

    while (t1 != NULL && t2 != NULL) {
        if (t1->exp > t2->exp) {
            insertSorted(&resHead, &resTail, t1->coeff, t1->exp);
            t1 = t1->next;
        } else if (t1->exp < t2->exp) {
            insertSorted(&resHead, &resTail, t2->coeff, t2->exp);
            t2 = t2->next;
        } else {
            int sumCoeff = t1->coeff + t2->coeff;
            if (sumCoeff != 0) {
                insertSorted(&resHead, &resTail, sumCoeff, t1->exp);
            }
            t1 = t1->next;
            t2 = t2->next;
        }
    }

    while (t1 != NULL) {
        insertSorted(&resHead, &resTail, t1->coeff, t1->exp);
        t1 = t1->next;
    }

    while (t2 != NULL) {
        insertSorted(&resHead, &resTail, t2->coeff, t2->exp);
        t2 = t2->next;
    }

    return resHead;
}

void freePolynomial(struct PolyNode** head) {
    struct PolyNode* current = *head;
    while (current != NULL) {
        struct PolyNode* next = current->next;
        free(current);
        current = next;
    }
    *head = NULL;
}

int main() {
    struct PolyNode *poly1Head = NULL, *poly1Tail = NULL;
    struct PolyNode *poly2Head = NULL, *poly2Tail = NULL;
    struct PolyNode *resultHead = NULL;

    int n, coeff, exp;

    printf("--- Polynomial 1 Setup ---\n");
    printf("Enter number of terms in Polynomial 1: ");
    if (scanf("%d", &n) != 1) return 0;
    for (int i = 0; i < n; i++) {
        printf("Enter coefficient and exponent for term %d: ", i + 1);
        scanf("%d %d", &coeff, &exp);
        insertSorted(&poly1Head, &poly1Tail, coeff, exp);
    }

    printf("\n--- Polynomial 2 Setup ---\n");
    printf("Enter number of terms in Polynomial 2: ");
    if (scanf("%d", &n) != 1) return 0;
    for (int i = 0; i < n; i++) {
        printf("Enter coefficient and exponent for term %d: ", i + 1);
        scanf("%d %d", &coeff, &exp);
        insertSorted(&poly2Head, &poly2Tail, coeff, exp);
    }

    resultHead = addPolynomials(poly1Head, poly2Head);

    printf("\n--- Results ---\n");
    printf("Polynomial 1: ");
    displayPolynomial(poly1Head);

    printf("Polynomial 2: ");
    displayPolynomial(poly2Head);

    printf("Resultant Polynomial: ");
    displayPolynomial(resultHead);

    freePolynomial(&poly1Head);
    freePolynomial(&poly2Head);
    freePolynomial(&resultHead);

    return 0;
}
