#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* next;
};

struct Node *first = NULL;
struct Node *last = NULL;

void display() {
    if (first == NULL) {
        printf("List is empty.\n");
        return;
    }
    struct Node* temp = first;
    printf("Circular Linked List: ");
    do {
        printf("%d -> ", temp->data);
        temp = temp->next;
    } while (temp != first);
    printf("(back to head)\n");
}

void insertAtEnd(int value) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = value;

    if (first == NULL) {
        first = last = newNode;
        last->next = first;
    } else {
        last->next = newNode;
        last = newNode;
        last->next = first;
    }
    printf("Inserted %d at the end.\n", value);
    display();
}

void deleteAtBeginning() {
    if (first == NULL) {
        printf("List is empty. Deletion not possible.\n");
        return;
    }

    struct Node* temp = first;
    if (first == last) {
        first = last = NULL;
    } else {
        first = first->next;
        last->next = first;
    }
    printf("Deleted %d from the beginning.\n", temp->data);
    free(temp);
    display();
}

void deleteAtEnd() {
    if (first == NULL) {
        printf("List is empty. Deletion not possible.\n");
        return;
    }

    if (first == last) {
        printf("Deleted %d from the end.\n", first->data);
        free(first);
        first = last = NULL;
    } else {
        struct Node* temp = first;
        while (temp->next != last) {
            temp = temp->next;
        }
        printf("Deleted %d from the end.\n", last->data);
        free(last);
        last = temp;
        last->next = first;
    }
    display();
}

int main() {
    int choice, value;

    while (1) {
        printf("\n--- Circular Singly Linked List Operations ---\n");
        printf("1. Insert at End\n");
        printf("2. Delete from Beginning\n");
        printf("3. Delete from End\n");
        printf("4. Display List\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");

        if (scanf("%d", &choice) != 1) {
            printf("Invalid input.\n");
            break;
        }

        switch (choice) {
            case 1:
                printf("Enter value to insert: ");
                scanf("%d", &value);
                insertAtEnd(value);
                break;
            case 2:
                deleteAtBeginning();
                break;
            case 3:
                deleteAtEnd();
                break;
            case 4:
                display();
                break;
            case 5:
                exit(0);
            default:
                printf("Invalid choice! Please try again.\n");
        }
    }

    return 0;
}
