#include <stdio.h>
#include <string.h>

#define MAX 100

int main() {
    char str[MAX], exp[MAX], stack[MAX];
    int top, i, flag;

    printf("Enter a string: ");
    scanf("%99s", str);

    top = -1;
    flag = 1;

    for (i = 0; str[i] != '\0'; i++)
        stack[++top] = str[i];

    for (i = 0; str[i] != '\0'; i++) {
        if (str[i] != stack[top--]) {
            flag = 0;
            break;
        }
    }

    if (flag)
        printf("Palindrome\n");
    else
        printf("Not a palindrome\n");

    printf("Enter an expression: ");
    scanf("%99s", exp);

    top = -1;
    flag = 1;

    for (i = 0; exp[i] != '\0'; i++) {
        if (exp[i] == '(' || exp[i] == '{' || exp[i] == '[')
            stack[++top] = exp[i];

        else if (exp[i] == ')' || exp[i] == '}' || exp[i] == ']') {
            if (top == -1 ||
                (exp[i] == ')' && stack[top] != '(') ||
                (exp[i] == '}' && stack[top] != '{') ||
                (exp[i] == ']' && stack[top] != '[')) {
                flag = 0;
                break;
            }
            top--;
        }
    }

    if (top != -1)
        flag = 0;

    if (flag)
        printf("Parentheses are balanced\n");
    else
        printf("Parentheses are not balanced\n");

    return 0;
}