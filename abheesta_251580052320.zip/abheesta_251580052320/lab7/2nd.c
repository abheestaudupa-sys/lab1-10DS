#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

struct Node {
    char data;
    struct Node *next;
};

struct Node *top = NULL;

void push(char ch) {
    struct Node *newNode = malloc(sizeof(struct Node));
    newNode->data = ch;
    newNode->next = top;
    top = newNode;
}

char pop() {
    if (top == NULL)
        return '\0';

    struct Node *temp = top;
    char ch = temp->data;
    top = top->next;
    free(temp);
    return ch;
}

char peek() {
    if (top == NULL)
        return '\0';
    return top->data;
}

int precedence(char ch) {
    if (ch == '^')
        return 3;
    if (ch == '*' || ch == '/' || ch == '%')
        return 2;
    if (ch == '+' || ch == '-')
        return 1;
    return 0;
}

void infixToPostfix(char infix[], char postfix[]) {
    int i, j = 0;
    char ch;

    while (top != NULL)
        pop();

    for (i = 0; infix[i] != '\0'; i++) {
        ch = infix[i];

        if (isalnum((unsigned char)ch))
            postfix[j++] = ch;

        else if (ch == '(')
            push(ch);

        else if (ch == ')') {
            while (top != NULL && peek() != '(')
                postfix[j++] = pop();

            if (top != NULL)
                pop();
        }

        else {
            while (top != NULL && peek() != '(' &&
                  (precedence(peek()) > precedence(ch) ||
                  (precedence(peek()) == precedence(ch) && ch != '^')))
                postfix[j++] = pop();

            push(ch);
        }
    }

    while (top != NULL)
        postfix[j++] = pop();

    postfix[j] = '\0';
}

struct EvalNode {
    int data;
    struct EvalNode *next;
};

struct EvalNode *evalTop = NULL;

void pushValue(int value) {
    struct EvalNode *newNode = malloc(sizeof(struct EvalNode));
    newNode->data = value;
    newNode->next = evalTop;
    evalTop = newNode;
}

int popValue() {
    if (evalTop == NULL) {
        printf("Invalid postfix expression\n");
        exit(1);
    }

    struct EvalNode *temp = evalTop;
    int value = temp->data;
    evalTop = evalTop->next;
    free(temp);
    return value;
}

int evaluatePostfix(char postfix[]) {
    int i, a, b;
    char ch;

    for (i = 0; postfix[i] != '\0'; i++) {
        ch = postfix[i];

        if (isdigit((unsigned char)ch))
            pushValue(ch - '0');

        else {
            b = popValue();
            a = popValue();

            switch (ch) {
                case '+': pushValue(a + b); break;
                case '-': pushValue(a - b); break;
                case '*': pushValue(a * b); break;
                case '/':
                    if (b == 0) {
                        printf("Division by zero\n");
                        exit(1);
                    }
                    pushValue(a / b);
                    break;
                case '^': pushValue((int)pow(a, b)); break;
                default:
                    printf("Invalid operator\n");
                    exit(1);
            }
        }
    }

    a = popValue();

    if (evalTop != NULL) {
        printf("Invalid postfix expression\n");
        exit(1);
    }

    return a;
}

int main() {
    char infix[100], postfix[100];

    printf("Enter infix expression: ");
    scanf("%99s", infix);

    infixToPostfix(infix, postfix);
    printf("Postfix expression: %s\n", postfix);

    printf("Enter numeric postfix expression: ");
    scanf("%99s", postfix);

    printf("Result: %d\n", evaluatePostfix(postfix));

    return 0;
}