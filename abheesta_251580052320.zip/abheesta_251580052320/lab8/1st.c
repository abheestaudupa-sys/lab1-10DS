#include <stdio.h>

#define MAX 5

struct Job {
    int id;
    char name[50];
};

struct Job queue[MAX];
int front = 0, rear = -1, count = 0;

void enqueue(int id, char name[]) {
    if (count == MAX) {
        printf("Queue is full\n");
        return;
    }

    rear = (rear + 1) % MAX;
    queue[rear].id = id;
    snprintf(queue[rear].name, sizeof(queue[rear].name), "%s", name);
    count++;

    printf("Print job added\n");
}

void dequeue() {
    if (count == 0) {
        printf("Queue is empty\n");
        return;
    }

    printf("Printing ID: %d, Document: %s\n",
           queue[front].id, queue[front].name);

    front = (front + 1) % MAX;
    count--;
}

int main() {
    int choice, id;
    char name[50];

    do {
        printf("\n1. Add print job\n");
        printf("2. Print next job\n");
        printf("3. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter document ID: ");
                scanf("%d", &id);

                printf("Enter document name: ");
                scanf("%49s", name);

                enqueue(id, name);
                break;

            case 2:
                dequeue();
                break;

            case 3:
                printf("Exiting printer queue\n");
                break;

            default:
                printf("Invalid choice\n");
        }
    } while (choice != 3);

    return 0;
}