#include <stdio.h>
#include <stdlib.h>

struct Patient {
    char name[50];
    int age, priority;
    struct Patient *next;
};

struct Patient *front = NULL, *rear = NULL;

void enqueue() {
    struct Patient *newNode = malloc(sizeof(struct Patient));

    if (newNode == NULL) {
        printf("Memory allocation failed\n");
        return;
    }

    printf("Enter name, age and priority: ");
    scanf("%49s %d %d", newNode->name, &newNode->age,
          &newNode->priority);

    newNode->next = NULL;

    if (rear == NULL)
        front = rear = newNode;
    else {
        rear->next = newNode;
        rear = newNode;
    }

    printf("Patient added to queue\n");
}

void dequeue() {
    if (front == NULL) {
        printf("Queue is empty\n");
        return;
    }

    struct Patient *temp = front;

    printf("Serving patient: %s, Age: %d, Priority: %d\n",
           temp->name, temp->age, temp->priority);

    front = front->next;

    if (front == NULL)
        rear = NULL;

    free(temp);
}

void display() {
    struct Patient *temp = front;

    if (temp == NULL) {
        printf("Queue is empty\n");
        return;
    }

    printf("\nPatient Queue:\n");

    while (temp != NULL) {
        printf("Name: %s, Age: %d, Priority: %d\n",
               temp->name, temp->age, temp->priority);
        temp = temp->next;
    }
}

int main() {
    int choice;

    do {
        printf("\n1. Add Patient\n2. Serve Patient\n");
        printf("3. Display Queue\n4. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                enqueue();
                break;
            case 2:
                dequeue();
                break;
            case 3:
                display();
                break;
            case 4:
                printf("Exiting\n");
                break;
            default:
                printf("Invalid choice\n");
        }
    } while (choice != 4);

    return 0;
}