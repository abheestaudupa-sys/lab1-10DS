#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *left, *right;
};

struct Node *createTree() {
    int x;

    printf("Enter data (-1 for no node): ");
    scanf("%d", &x);

    if (x == -1)
        return NULL;

    struct Node *newNode = malloc(sizeof(struct Node));
    newNode->data = x;

    printf("Left child of %d:\n", x);
    newNode->left = createTree();

    printf("Right child of %d:\n", x);
    newNode->right = createTree();

    return newNode;
}

void inorder(struct Node *root) {
    struct Node *stack[100], *temp = root;
    int top = -1;

    while (temp != NULL || top != -1) {
        while (temp != NULL) {
            stack[++top] = temp;
            temp = temp->left;
        }

        temp = stack[top--];
        printf("%d ", temp->data);
        temp = temp->right;
    }
}

void preorder(struct Node *root) {
    struct Node *stack[100];
    int top = -1;

    if (root == NULL)
        return;

    stack[++top] = root;

    while (top != -1) {
        struct Node *temp = stack[top--];
        printf("%d ", temp->data);

        if (temp->right != NULL)
            stack[++top] = temp->right;

        if (temp->left != NULL)
            stack[++top] = temp->left;
    }
}

void postorder(struct Node *root) {
    struct Node *stack[100], *temp = root, *last = NULL;
    int top = -1;

    while (temp != NULL || top != -1) {
        if (temp != NULL) {
            stack[++top] = temp;
            temp = temp->left;
        } else {
            struct Node *peek = stack[top];

            if (peek->right != NULL && last != peek->right)
                temp = peek->right;
            else {
                printf("%d ", peek->data);
                last = stack[top--];
            }
        }
    }
}

struct Node *findParent(struct Node *root, int key) {
    if (root == NULL)
        return NULL;

    if ((root->left != NULL && root->left->data == key) ||
        (root->right != NULL && root->right->data == key))
        return root;

    struct Node *temp = findParent(root->left, key);

    if (temp != NULL)
        return temp;

    return findParent(root->right, key);
}

int height(struct Node *root) {
    if (root == NULL)
        return 0;

    int left = height(root->left);
    int right = height(root->right);

    return 1 + (left > right ? left : right);
}

int ancestors(struct Node *root, int key) {
    if (root == NULL)
        return 0;

    if (root->data == key)
        return 1;

    if (ancestors(root->left, key) ||
        ancestors(root->right, key)) {
        printf("%d ", root->data);
        return 1;
    }

    return 0;
}

int countLeaves(struct Node *root) {
    if (root == NULL)
        return 0;

    if (root->left == NULL && root->right == NULL)
        return 1;

    return countLeaves(root->left) +
           countLeaves(root->right);
}

int main() {
    struct Node *root;
    int choice, key;
    struct Node *parent;

    printf("Create binary tree:\n");
    root = createTree();

    do {
        printf("\n\n1. Inorder (Iterative)");
        printf("\n2. Postorder (Iterative)");
        printf("\n3. Preorder (Iterative)");
        printf("\n4. Parent of an element");
        printf("\n5. Height of tree");
        printf("\n6. Ancestors of an element");
        printf("\n7. Count leaf nodes");
        printf("\n8. Exit");
        printf("\nEnter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Inorder: ");
                inorder(root);
                break;

            case 2:
                printf("Postorder: ");
                postorder(root);
                break;

            case 3:
                printf("Preorder: ");
                preorder(root);
                break;

            case 4:
                printf("Enter element: ");
                scanf("%d", &key);

                if (root != NULL && root->data == key)
                    printf("Root has no parent");
                else {
                    parent = findParent(root, key);

                    if (parent != NULL)
                        printf("Parent: %d", parent->data);
                    else
                        printf("Element not found");
                }
                break;

            case 5:
                printf("Height: %d", height(root));
                break;

            case 6:
                printf("Enter element: ");
                scanf("%d", &key);

                if (root != NULL && root->data == key)
                    printf("Root has no ancestors");
                else if (!ancestors(root, key))
                    printf("Element not found");
                break;

            case 7:
                printf("Leaf nodes: %d", countLeaves(root));
                break;

            case 8:
                printf("Exiting");
                break;

            default:
                printf("Invalid choice");
        }
    } while (choice != 8);

    return 0;
}