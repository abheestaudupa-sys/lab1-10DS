#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *left, *right;
};

struct Node* createTree() {
    int x;

    printf("Enter data (-1 for no node): ");
    scanf("%d", &x);

    if (x == -1)
        return NULL;

    struct Node *newNode = malloc(sizeof(struct Node));
    newNode->data = x;

    printf("Left child of %d:\n", x);
    newNode->left = createTree();

    printf("Right child of %d:\n", x);
    newNode->right = createTree();

    return newNode;
}

void levelOrder(struct Node *root) {
    if (root == NULL)
        return;

    struct Node *queue[100];
    int front = 0, rear = 0;

    queue[rear++] = root;

    while (front < rear) {
        struct Node *temp = queue[front++];
        printf("%d ", temp->data);

        if (temp->left != NULL)
            queue[rear++] = temp->left;

        if (temp->right != NULL)
            queue[rear++] = temp->right;
    }
}

int main() {
    struct Node *root;

    printf("Create binary tree:\n");
    root = createTree();

    printf("Level-order traversal: ");
    levelOrder(root);

    return 0;
}